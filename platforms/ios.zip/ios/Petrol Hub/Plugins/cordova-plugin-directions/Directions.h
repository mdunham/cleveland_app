#import <Cordova/CDV.h>

@interface Directions : CDVPlugin

- (void) navigateTo:(CDVInvokedUrlCommand*)command;

@end