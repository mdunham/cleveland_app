SELECT "StateID" as state_id,  FROM dbo."T-COUNTY TAX";
