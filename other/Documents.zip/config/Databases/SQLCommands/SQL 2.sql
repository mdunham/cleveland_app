SELECT "CITY CODE" as city_code, "CITY NAME" as name, "StateID" as state_id, "CITY TAX RATE" as rate FROM dbo."T-CITY TAX";
